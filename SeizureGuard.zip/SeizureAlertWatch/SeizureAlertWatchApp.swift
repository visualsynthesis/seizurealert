import SwiftUI

@main
struct SeizureAlertWatchApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
